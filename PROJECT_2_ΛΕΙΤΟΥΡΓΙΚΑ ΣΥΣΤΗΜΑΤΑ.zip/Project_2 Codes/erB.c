#include <stdio.h>
#include <unistd.h>
#include <pthread.h>
#include <semaphore.h>

pthread_mutex_t reader_mutex , writer_mutex;
sem_t rsem, wsem;

int counter = 1; // shared variable
int readers = 0; // The number of readers
int writers = 0; // The number of writers

void *reader(void *reader_index)
{
    printf("\n Reader %d is created\n", *((int *)reader_index));
	
    // Only one reader-thread at a time increases the number of readers
    pthread_mutex_lock(&reader_mutex);
    readers++;
    pthread_mutex_unlock(&reader_mutex);
    
    sem_wait(&rsem);
    sleep(1);
    
    printf("\n Reader %d reads counter as %d\n", *((int *)reader_index), counter);
    
    // Only one reader-thread at a time decreases the number of readers
    pthread_mutex_lock(&reader_mutex);
    readers--;
    pthread_mutex_unlock(&reader_mutex);
    
    if (writers == 0) {
    	sem_post(&rsem); // if there are no writers left, next it's a reader's turn
    }
    else {
    	sem_post(&wsem); // otherwise, next it's a writer's turn
    }
    
    return reader_index;
}

void *writer(void* writer_index)
{
    printf("\n Writer %d is created\n", *((int *)writer_index));
    
    // Only one writer-thread at a time increases the number of writers
    pthread_mutex_lock(&writer_mutex);
    writers++;
    pthread_mutex_unlock(&writer_mutex);
    
    sem_wait(&wsem);
    sleep(1);
    
    // The writer-thread modifies counter's value
    counter *= 2;
    printf("\n Writer %d modifies counter as %d\n", *((int *)writer_index), counter);
    
    // Only one writer-thread at a time decreases the number of writers
    pthread_mutex_lock(&writer_mutex);
    writers--;
    pthread_mutex_unlock(&writer_mutex);
    
    if (readers == 0) {
    	sem_post(&wsem); // if there are no readers left, next it's a writer's turn
    }
    else {
    	sem_post(&rsem); // otherwise, next it's a reader's turn
    }
    
    return writer_index;
}

int main()
{
    pthread_t readers[10], writers[10]; // we are having 10 readers and 10 writers
   
    pthread_mutex_init(&reader_mutex, NULL);
    pthread_mutex_init(&writer_mutex , NULL);

    sem_init(&rsem, 0, 1); // rsem initialized to 1
    sem_init(&wsem, 0, 0); // wsem initialized to 0

    int i;
    int num_labels[10] = {1,2,3,4,5,6,7,8,9,10}; // used for numbering readers and writers

    for(i = 0; i < 10; i++) {
        pthread_create(&readers[i], NULL, reader, (void *)&num_labels[i]);
        pthread_create(&writers[i], NULL, writer, (void *)&num_labels[i]);
    }
    
    for(i = 0; i < 10; i++) {
        pthread_join(readers[i], NULL);
        pthread_join(writers[i], NULL);
    }
    
    pthread_mutex_destroy(&writer_mutex);
    pthread_mutex_destroy(&reader_mutex);
    
    sem_destroy(&rsem);
    sem_destroy(&wsem);

    return 0;
}
