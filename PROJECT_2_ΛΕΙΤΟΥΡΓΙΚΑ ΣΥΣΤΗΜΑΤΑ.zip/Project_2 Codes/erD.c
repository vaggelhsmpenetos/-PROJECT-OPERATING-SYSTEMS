#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/shm.h>
#include <errno.h>
#include <fcntl.h>
#include <time.h>
#include <semaphore.h>
#include <sys/wait.h>

#define N 5       // Number of parking spaces
#define ONE 1

typedef struct {
	int free_s;
	int free_a[N];
} shared_mem;

shared_mem *vars;

typedef sem_t Semaphore;
Semaphore *s0; 
Semaphore *s1;

// Car enters the parking area and takes a free parking space
int Enter_p() {
	
	while (vars->free_s == 0); // await(free_s > 0);
	vars->free_s--;
	
	time_t t;
	int free_p;
	srand((unsigned) time(&t)); // intializes random number generator
	
	// Epilogi_thesis(): finds a free parking space
	do {
		free_p = rand() % N;
	} while (vars->free_a[free_p] == 0);
	
	// The free parking space is taken
	vars->free_a[free_p] = 0;
	return free_p;
}

// Car leaves an already taken parking space
void Leave_p(int free_p) {
	vars->free_s++;
	vars->free_a[free_p] = 1;
}

int main() {
	
	int i;
	key_t shmkey;
	int shmid;
	pid_t pid;
	
	// Initialize a shared variable in shared memory
	// valid directory name and a number
	shmkey = ftok("/dev/null", 5);       
	shmid = shmget(shmkey, sizeof(int), 0644 | IPC_CREAT);

	// Shared memory error check
	if (shmid < 0)                           
	{
		perror("shmget\n");
		exit(1);
	}
								       
	// Attach 'vars' to shared memory
	vars  = (shared_mem *) shmat(shmid, NULL, 0);  
	
	// Initialize variables of the shared memory
	vars->free_s = N;
	for (i = 0; i < N; i++) {
		vars->free_a[i] = 1; // all parking spaces are, initially, free
	}
	
	// Initialize semaphores for shared processes
    s0 = sem_open("S0", O_CREAT | O_EXCL, 0644, ONE); 
    s1 = sem_open("S1", O_CREAT | O_EXCL, 0644, ONE); 

	// Fork children
	for (i = 0; i < 10; i++) {
		pid = fork();
		
		if (pid == 0) {
			break;
		}
	}
	// Parent process
	if (pid > 0) {
		// The parent process waits for its children to finish
		pid = waitpid(-1, NULL, 0);
		while (pid) {
			if (errno == ECHILD) {
				break;
			}
			pid = waitpid(-1, NULL, 0);
		}
		printf (" All cars have exited the parking area.\n");
		
        // Unlink the semaphores
        sem_unlink("S0");   
        sem_close(s0); 
        sem_unlink("S1");   
        sem_close(s1); 
		
		// Dettach the shared memory space
		shmdt(vars);
        shmctl(shmid, IPC_RMID, 0);
    }
    // Child process
    else {
    	sem_wait(s0); // down(s0)
        int free_p = Enter_p();
        printf(" -> Car(%d) takes the %d parking space.\n", i, free_p);
        sem_post(s0); // up(s0)
        
        // Every car-process stays in the selected parking space for random seconds (2-10 seconds)
        int seconds = rand() % 9 + 2;
        printf("    [stays for %d seconds]\n\n", seconds);
        sleep(seconds);
        
        sem_wait(s1); // down(s1)
		Leave_p(free_p);
		printf(" <- Car(%d) leaves the %d parking space.\n\n", i, free_p);
		sem_post(s1); // up(s1)
	}
	
	exit(0);
}
