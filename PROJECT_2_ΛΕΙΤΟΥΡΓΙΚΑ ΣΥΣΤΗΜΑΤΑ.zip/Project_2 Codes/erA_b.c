#include <stdio.h>
#include <stdlib.h>
#include <sys/shm.h>
#include <errno.h>
#include <semaphore.h>
#include <fcntl.h>
#include <time.h>
#include <zconf.h>
#include <sys/wait.h>

#define ONE 1
#define N 10  // The number of child processes

typedef sem_t Semaphore;
Semaphore *mutex;

// MIN HEAP TREE struct
typedef struct Heap{
    int *arr;
    int count;
    int capacity;
} Heap;

Heap *CreateHeap(int capacity){
    Heap *h = (Heap *) malloc(sizeof(Heap));
    if (h == NULL)
        printf("Memory Error!");

    h -> count=0;
    h -> capacity = capacity;
    h -> arr = (int *) malloc(capacity * sizeof(int));

    if (h -> arr == NULL)
        printf("Memory Error!");
    return h;
}

void heapify_bottom_top(Heap *h, int index){
    int temp;
    int parent_node = (index-1)/2;

    if (h -> arr[parent_node] > h -> arr[index]) {
        temp = h -> arr[parent_node];
        h -> arr[parent_node] = h -> arr[index];
        h -> arr[index] = temp;
        heapify_bottom_top(h,parent_node);
    }
}

void heapify_top_bottom(Heap *h, int parent_node){
    int left = parent_node*2 + 1;
    int right = parent_node*2 + 2;
    int min;
    int temp;

    if (left >= h->count || left < 0)
        left = -1;
    if (right >= h->count || right < 0)
        right = -1;

    if (left != -1 && h -> arr[left] < h -> arr[parent_node])
        min = left;
    else
        min = parent_node;
    if (right != -1 && h -> arr[right] < h -> arr[min])
        min = right;

    if (min != parent_node){
        temp = h -> arr[min];
        h -> arr[min] = h -> arr[parent_node];
        h -> arr[parent_node] = temp;

        heapify_top_bottom(h, min);
    }
}

void insert(Heap *h, int key){
    if (h -> count < h -> capacity) {
        h -> arr[h->count] = key;
        heapify_bottom_top(h, h -> count);
        h -> count++;
    }
}

int PopMin(Heap *h){
    int pop;
    if(h->count==0){
        printf("\n__Heap is Empty__\n");
        return -1;
    }
    // replace first node by last and delete last
    pop = h->arr[0];
    h->arr[0] = h->arr[h->count-1];
    h->count--;
    heapify_top_bottom(h, 0);
    return pop;
}

void print(Heap *h){
    int i;
    printf("\n____________Print Heap_____________\n");
    for(i=0; i< h -> count; i++) {
        printf("-> %02d ",h->arr[i]);
    }
    printf("->__/\\__\n");
}

int main() {
	
    int i;
    int sum;
    int *p;
    key_t shmkey; // shared memory key
    int shmid;    // shared memory id
    pid_t pid;
    clock_t start, end;

    Heap *shared_heap;
    shared_heap = CreateHeap(10*N);

    mutex = sem_open("heapSem", O_CREAT | O_EXCL, 0644, ONE); // Semaphore

	shmkey = ftok("/dev/null", 5);       
	shmid = shmget(shmkey, sizeof(int), 0644 | IPC_CREAT);

	// Shared memory error check
	if (shmid < 0)                           
	{
		perror("shmget\n");
		exit(1);
	}
								       
	// Attach p to shared memory
    p  = (int *)shmat(shmid, NULL, 0);   
    *p = 0;

	// insert all the distinct number in the heap
	for (i = 1; i <= 10 * N; i++) {
		insert(shared_heap, i);
	}
	print(shared_heap);
	
	start = clock();
	
	// Fork N children
    for (i = 0; i < N; i++) {
        pid = fork();

        if (pid == 0) {
            break;
        }
    }
    // Parent process
    if (pid > 0) {
    	// The parent process waits for its children to finish
        pid = waitpid(-1, NULL, 0);
        while (pid) {
            if (errno == ECHILD) {
                break;
            }
            pid = waitpid(-1, NULL, 0);
        }

        print(shared_heap); // print the final heap
        printf("\n Parent: All children have exited.\n");
        printf(" [final value of *p=%d]\n\n", *p);

		end = clock();
		printf(" Total time = %g\n\n", (double)(end - start)/CLOCKS_PER_SEC);
		
	// Detach the shared memory space	
        shmdt(p);
        shmctl(shmid, IPC_RMID, 0);

        sem_unlink("heapSem");
        sem_close(mutex);
    }
    // Child process
    else {
		int j;
		// every child process updates *p 10 times
		for (j = 0; j < 10; j++) {
			sem_wait(mutex); // down
			
			sum = *p;
			int num = PopMin(shared_heap); // pop the minimum value from the heap
			sum += num;
			*p = sum;
			
	        printf(" Child(%d) changed *p to : %d\n", i, *p);
			sem_post(mutex); // up
		}
    }

    exit(0);
}
