#include <stdio.h>
#include <stdlib.h>
#include <pthread.h>
#include <semaphore.h>
#include <unistd.h>

sem_t s1, s2;
int semVal;

void* SC1(void* arg) {
    printf("** Entered SC1 **\n");

    // Lists all files and directories in the present working directory 
    system("ls -l");

    // signal
    printf("** Exiting SC1 **\n");
    sem_post(&s1);
    sem_getvalue(&s1, &semVal);
    printf("----[S1 = %d]----\n\n", semVal);
}

void* SC2(void* arg) {
    printf("** Entered SC2 **\n");

	// Lists the currently running processes and their PIDs along with some other information
    system("ps -l");

    // signal
    printf("** Exiting SC2 **\n");
    sem_post(&s1);
    sem_getvalue(&s1, &semVal);
    printf("----[S1 = %d]----\n\n", semVal);
}

void* SC3(void* arg) {
    printf("** Entered SC3 **\n");

	// display system status
    system("uptime");

    // signal
    printf("** Exiting SC3 **\n");
    sem_post(&s2);
    sem_getvalue(&s2, &semVal);
    printf("----[S2 = %d]----\n\n", semVal);
}

void* SC4(void* arg) {
    // wait
    sem_wait(&s1);
    sem_wait(&s1);
    sem_getvalue(&s1, &semVal);
    printf("----[S1 = %d]----\n", semVal);
    printf("** Entered SC4 **\n");
    
	// Shows the usernames of users currently logged in to the current host 
    system("users"); //

	// signal
    printf("** Exiting SC4 **\n");
    sem_post(&s2);
    sem_getvalue(&s2, &semVal);
    printf("----[S2 = %d]----\n\n", semVal);
}

void* SC5(void* arg) {
    // wait
    sem_wait(&s2);
    sem_wait(&s2);
    sem_getvalue(&s2, &semVal);
    printf("----[S2 = %d]----\n", semVal);
    printf("** Entered SC5 **\n");

	// Get the path to the current directory
    system("pwd"); 

    printf("** Exiting SC5 **\n\n");
}

int main() {
    
    // Initialize semaphores
    sem_init(&s1, 0, 0);
    sem_init(&s2, 0, 0);
    
    pthread_t t1, t2, t3, t4, t5;
    pthread_create(&t1, NULL, SC1, NULL);
    sleep(2);
    pthread_create(&t2, NULL, SC2, NULL);
    sleep(2);
    pthread_create(&t3, NULL, SC3, NULL);
    sleep(2);
    pthread_create(&t4, NULL, SC4, NULL);
    sleep(2);
    pthread_create(&t5, NULL, SC5, NULL);

    pthread_join(t1, NULL);
    pthread_join(t2, NULL);
    pthread_join(t3, NULL);
    pthread_join(t4, NULL);
    pthread_join(t5, NULL);

    sem_destroy(&s1);
    sem_destroy(&s2);
    
    return 0;
}
