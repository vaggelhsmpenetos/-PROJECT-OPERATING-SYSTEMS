#include <stdio.h>
#include <stdlib.h>
#include <sys/types.h>
#include <sys/shm.h>
#include <errno.h>
#include <fcntl.h>
#include <zconf.h>
#include <sys/wait.h>

#define N 2       // Number of children
#define MAX 500   // The max value of the loop


typedef struct {
	int X;
	int flag[N];
	int turn;
} shared_mem;

shared_mem *vars;


// Executed before entering critical section
void enter_region(int process) {
	vars->flag[process] = 1;
	vars->turn = 1-process;
	while (vars->flag[1-process] == 1 && vars->turn == 1-process);
}

// Executed after leaving critical section
void leave_region(int process) {
	vars->flag[process] = 0;
}

// Executed by every child process
void child_process_i() {
	int i, tmp;
	
	for (i = 1; i <= MAX; i++) {
		tmp = vars->X;
		tmp = tmp + 1;
		vars->X = tmp;
	}
}

int main() {
	
	int i;
	key_t shmkey;  // shared memory key
    	int shmid;     // shared memory id
    	pid_t pid;     // fork pid
								       
	// Initialize a shared variable in shared memory
	// valid directory name and a number
	shmkey = ftok("/dev/null", 5);       
	shmid = shmget(shmkey, sizeof(shared_mem), 0644 | IPC_CREAT);

	// Shared memory error check
	if (shmid < 0)                           
	{
		perror("shmget\n");
		exit(1);
	}
								       
	// Attach 'vars' to shared memory
	vars  = (shared_mem *) shmat(shmid, NULL, 0);  
	
	// The initial value of X is 0
	vars->X = 0;
	
	// Initialize lock by resetting the desire of both the threads to
	// acquire the locks. And, giving turn to one of them.
  	vars->flag[0] = 0;
  	vars->flag[1] = 0;
  	vars->turn = 0;

	// Fork two children
	for (i = 0; i < N; i++) {
		pid = fork();
		
		if (pid == 0) {
			break;
		}
	}
	// Parent process
	if (pid > 0) {
		// The parent process waits for its children to finish
		pid = waitpid(-1, NULL, 0);
		while (pid) {
			if (errno == ECHILD) {
				break;
			}
			pid = waitpid(-1, NULL, 0);
		}
		
		printf (" Parent: All children have exited.\n");
		printf(" Actual value of X: %d | Expected value of X: %d\n", vars->X, 2*MAX);
		
		// Detach the shared memory space
		shmdt(vars);
        	shmctl(shmid, IPC_RMID, 0);
        }
        // Child process
        else {
        	enter_region(i);
		printf(" Child(%d) enters the critical section.\n", i);
		child_process_i();
		printf(" Child(%d) exits the critical section.\n\n", i);
		printf (" new value of X=%d.\n\n\n", vars->X);
		leave_region(i);
	}
	
	exit(0);
}
